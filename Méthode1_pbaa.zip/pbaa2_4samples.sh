#!/bin/bash
#SBATCH --job-name=pbaa
#SBATCH --ntasks=1
#SBATCH --mem=16G
#SBATCH -p fast
#SBATCH --qos=fast
#SBATCH --cpus-per-task=8
#SBATCH --array=1-4


#################################################################################

OUTPUT='/home/newatil/pbaa2'

### errors management
### set -x #mode debug on
set -o errexit #pour que le script s'arrete en cas d erreur ignoree
set -o nounset #force l initialisation des variables
IFS=$'\n\t'

### modules management
module load gcc/8.1.0 smrttools/10.1.0.119588 samtools/1.9

########################################################################################################

SCRATCHDIR=/storage/scratch/$USER/${SLURM_ARRAY_JOB_ID}_${SLURM_ARRAY_TASK_ID}
mkdir -p -m 750 ${SCRATCHDIR}
cd ${SCRATCHDIR}
mkdir -p ${OUTPUT}

########################################################################################################

sample=("bc2088" "bc2093" "bc2094" "bc2095")
s=${sample[$SLURM_ARRAY_TASK_ID]}
FILE=$(\ls -1 /home/newatil/PacBio/demux.${s}--${s}.bam)
SHORTNAME=$(basename ${FILE} |cut -d'.' -f1-2)


echo '*****************************************************************************'
echo "start job  ${SLURM_JOB_ID}_${SLURM_ARRAY_TASK_ID} on ${HOSTNAME} at `date`"
echo '************ PacBio Amplicon Analysis of sample' ${SHORTNAME}' ***************'

######## smrttools/bam2fastq #############################################################
echo '######## convert bam to fastq ################'
samtools fastq ${FILE} > ${SHORTNAME}.fastq

echo '######## create indedx with fqidx #############'

samtools fqidx ${SHORTNAME}.fastq

echo '################ Runing pbaa ##################################'

pbaa cluster -j 8 --max-consensus-reads 1000 --log-file ${SHORTNAME}.log /home/palasser/soutien_bioinfo/WATIL_stageM2/18_amplicons_GLU_CSRefSeqv1.fasta ${SHORTNAME}.fastq pbaa_${SHORTNAME}

#sed -i 's/HMW_/HMW/g' pbaa_${SHORTNAME}*.fasta

############ move output data ###################
echo '####################### start moving data #####################################'

rm ${SCRATCHDIR}/${SHORTNAME}.fastq
rm ${SCRATCHDIR}/${SHORTNAME}.fastq.fai
mv ${SCRATCHDIR}/${SHORTNAME}.log ${OUTPUT}/
mv ${SCRATCHDIR}/pbaa_* ${OUTPUT}/ && rm -Rf ${SCRATCHDIR}

echo '********* DONE *******************'

