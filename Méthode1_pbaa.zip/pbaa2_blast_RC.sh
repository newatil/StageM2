#!/bin/bash
#SBATCH --job-name=pbaa2_rc
#SBATCH --ntasks=1
#SBATCH --mem=64G
#SBATCH -p debug
##SBATCH --qos=fast
#SBATCH --cpus-per-task=32
##SBATCH --array=1-94

OUTPUT='/home/newatil/pbaa2_RC'
mkdir -p ${OUTPUT}
cd ${OUTPUT}

#################################
ml java/oracle-1.8.0_45  emboss/6.5.7
#################################

file=$(\ls -1 /home/newatil/pbaa2/pbaa_demux*passed_cluster_sequences.fasta)

for f in $file; do seqretsplit -sequence $f;done
