#!/bin/bash
#SBATCH --job-name=pbaa_clustalo
#SBATCH --ntasks=1
#SBATCH --mem=16G
#SBATCH -p fast
#SBATCH --qos=fast
#SBATCH --cpus-per-task=8
#SBATCH --array=0-17
#################################################################################
OUTPUT='/home/newatil/pbaClustal_V2'

echo '******************************************'
echo 'Alignement multiple'
echo '******************************************'

### modules management
module load  ClustalOmega/1.2.4

### working directory analysis in scratch

mkdir -p ${OUTPUT}
cd ${OUTPUT}

########################################################################################################
genes=("hmw1ax" "hmw1bx" "hmw1dx" "hmw_1by" "hmw1ay" "hmw_1dy" "lmw1a_i_1" "lmw1a_i_2" "lmw1a_m_3" "lmw1b_m_4" "lmw1b_m_5" "lmw1d_m_1" "lmw1d_m_3" "lmw1d_m_4" "lmw1d_m_5" "lmw1d_m_6" "lmw1d_m_7" "lmw1d_m_8")

g=${genes[$SLURM_ARRAY_TASK_ID]}
cat /home/newatil/pbaa-seq/sample*${g}*fasta > pbaa_${g}.fasta


######## Run the program

clustalo  -i pbaa_${g}.fasta -t  DNA  -o ${OUTPUT}/pbaa_${g}_aling.fasta
###########################################################################################################
echo '********************************DONE********************************'
