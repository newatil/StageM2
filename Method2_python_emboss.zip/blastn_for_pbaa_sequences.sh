#!/bin/bash
#SBATCH --job-name=BLAST_pbaa
#SBATCH --ntasks=1
#SBATCH --mem=32G
#SBATCH -p fast
#SBATCH --qos=fast
#SBATCH --cpus-per-task=8
#SBATCH --array=1-94

#############################################################
ml load ncbi-blast/2.11.0+ gdecTools/1.1  bioperl/1.7.0_rc5
#########################################################

OUTPUT='/home/newatil/blastn_pbaa2'
mkdir -p ${OUTPUT}
cd ${OUTPUT}
###################################################
##BLAST analysis
#################################################


for g in "hmw_1by" "hmw_1dy"
do 
	FILE=$(\ls -1 /home/newatil/pbaa2/sample*${g}_cluster-0*fasta |sed -n ${SLURM_ARRAY_TASK_ID}p)
	SHORTNAME=$(basename ${FILE} |cut -d'.' -f1)
	blastn -num_threads 8 -dust no -max_hsps 1 -outfmt "6 qaccver saccver pident length mismatch gapopen qstart qend qlen sstart send slen evalue score" -query /home/newatil/pbaa2/${g}_REFSEQV1.fasta -subject ${FILE} -out ${SHORTNAME}.blastn
done

#/home/newatil/pbaa2/sample-bc2096--bc2096_guide-lmw1d_m_7_cluster-0_readcount-1754.fasta
