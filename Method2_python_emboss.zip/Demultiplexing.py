#!/usr/bin/env python
# -*-coding:Latin-1 -*

import re
import os, sys
import glob
from collections import defaultdict
import collections

primer = [line for i, line in enumerate(open(sys.argv[2])) if i % 2 == 1 ]
for i in range(len(primer)):
	primer[i] = primer[i].upper()

filename=os.path.splitext(sys.argv[1])[0]

#print(filename) 
	
lol=[]
for i in primer:
	lol.append(i.strip())
#print(lol)
	
Glu_HPM_1Ax=[]
Glu_HPM_1Bx=[]
Glu_HPM_1Dx=[]
Glu_HPM_1Ay=[]
Glu_HPM_1By=[]
Glu_HPM_1Dy=[]
Glu_FPM_i_1_A=[]
Glu_FPM_i_2_A=[]
Glu_FPM_m_3_A=[]
Glu_FPM_m_4_B=[]
Glu_FPM_m_5_B=[]
Glu_FPM_m_1_D=[]
Glu_FPM_m_3_D=[]
Glu_FPM_m_4_D=[]
Glu_FPM_m_5_D=[]
Glu_FPM_m_6_D=[]
Glu_FPM_m_7_D=[]
Glu_FPM_m_8_D=[]

with open(sys.argv[1],"r") as my_file:
	data=my_file.read()
	data_split=data.split("\n")
	for i in range(len(data_split)):
		if i % 2:
			line = [data_split[i-1], data_split[i]]
			start=line[1][0:55]
			tail=line[1][-55:]
			if ((lol[0] in start or lol[2] in tail) or (lol[1] in start or lol[3] in tail)):
				Glu_HPM_1Ax.append(line)					
			elif ((lol[4] in start or lol[6] in tail) or (lol[5] in start or lol[7] in tail)):
				Glu_HPM_1Bx.append(line)
			elif ((lol[8] in start or lol[10] in tail) or (lol[9] in start or lol[11] in tail)):		
  				Glu_HPM_1Dx.append(line)
			elif ((lol[12] in start or lol[14] in tail) or (lol[13] in start or lol[15] in tail)):
				Glu_HPM_1Ay.append(line)
			elif ((lol[16] in start or lol[18] in tail) or (lol[17] in start or lol[19] in tail)):
				Glu_HPM_1By.append(line)
			elif ((lol[20] in start or lol[22] in tail) or (lol[21] in start or lol[23] in tail)):
				Glu_HPM_1Dy.append(line)
			elif ((lol[24] in start or lol[26] in tail) or (lol[25] in start or lol[27] in tail)):
				Glu_FPM_i_1_A.append(line)
			elif ((lol[28] in start or lol[30] in tail) or (lol[29] in start or lol[31] in tail)):
				Glu_FPM_i_2_A.append(line)
			elif ((lol[32] in start or lol[34] in tail) or (lol[33] in start or lol[35] in tail)):
				Glu_FPM_m_3_A.append(line)
			elif ((lol[36] in start or lol[38] in tail) or (lol[37] in start or lol[39] in tail)):
				Glu_FPM_m_4_B.append(line)
			elif ((lol[40] in start or lol[42] in tail) or (lol[41] in start or lol[43] in tail)):
				Glu_FPM_m_5_B.append(line)
			elif ((lol[44] in start or lol[46] in tail) or (lol[45] in start or lol[47] in tail)):
				Glu_FPM_m_1_D.append(line)
			elif ((lol[48] in start or lol[50] in tail) or (lol[49] in start or lol[51] in tail)):
				Glu_FPM_m_3_D.append(line)
			elif ((lol[52] in start or lol[54] in tail) or (lol[53] in start or lol[55] in tail)):
				Glu_FPM_m_4_D.append(line)
			elif ((lol[56] in start or lol[58] in tail) or (lol[57] in start or lol[59] in tail)):
				Glu_FPM_m_5_D.append(line)
			elif ((lol[60] in start or lol[62] in tail) or (lol[61] in start or lol[63] in tail)):
				Glu_FPM_m_6_D.append(line)
			elif ((lol[64] in start or lol[66] in tail) or (lol[65] in start or lol[67] in tail)):
				Glu_FPM_m_7_D.append(line)
			elif ((lol[68] in start or lol[70] in tail) or (lol[69] in start or lol[71] in tail)):
				Glu_FPM_m_8_D.append(line)

#print(len(CESA3),len(RPS4),len(RRS1))

for element in Glu_HPM_1Ax:
	if(len(element[1])<7000 or len(element[1])>7300):
		Glu_HPM_1Ax.remove(element)

for element in Glu_HPM_1Bx:
        if(len(element[1])<5900 or len(element[1])>6300):
                Glu_HPM_1Bx.remove(element)

for element in Glu_HPM_1Dx:
        if(len(element[1])<6000 or len(element[1])>6300):
                Glu_HPM_1Dx.remove(element)

for element in Glu_HPM_1Ay:
        if(len(element[1])<6500 or len(element[1])>6900):
                Glu_HPM_1Ay.remove(element)

for element in Glu_HPM_1By:
        if(len(element[1])<7400 or len(element[1])>7800):
                Glu_HPM_1By.remove(element)

for element in Glu_HPM_1Dy:
        if(len(element[1])<7350 or len(element[1])>7700):
                Glu_HPM_1Dy.remove(element)

for element in Glu_FPM_i_1_A:
        if(len(element[1])<4900 or len(element[1])>5250):
                Glu_FPM_i_1_A.remove(element)

for element in Glu_FPM_i_2_A:
        if(len(element[1])<8300 or len(element[1])>8600):
                Glu_FPM_i_2_A.remove(element)

for element in Glu_FPM_m_3_A:
        if(len(element[1])<6850 or len(element[1])>7200):
                Glu_FPM_m_3_A.remove(element)

for element in Glu_FPM_m_4_B:
        if(len(element[1])<6650 or len(element[1])>7050):
                Glu_FPM_m_4_B.remove(element)

for element in Glu_FPM_m_5_B:
        if(len(element[1])<7450 or len(element[1])>7900):
                Glu_FPM_m_5_B.remove(element)

for element in Glu_FPM_m_1_D:
        if(len(element[1])<4300 or len(element[1])>4700):
                Glu_FPM_m_1_D.remove(element)

for element in Glu_FPM_m_3_D:
        if(len(element[1])<6650 or len(element[1])>7050):
                Glu_FPM_m_3_D.remove(element)

for element in Glu_FPM_m_4_D:
        if(len(element[1])<7000 or len(element[1])>7400):
                Glu_FPM_m_4_D.remove(element)

for element in Glu_FPM_m_5_D:
        if(len(element[1])<7100 or len(element[1])>7550):
                Glu_FPM_m_5_D.remove(element)

for element in Glu_FPM_m_6_D:
        if(len(element[1])<6200 or len(element[1])>6650):
                Glu_FPM_m_6_D.remove(element)

for element in Glu_FPM_m_7_D:
        if(len(element[1])<7250 or len(element[1])>7700):
                Glu_FPM_m_7_D.remove(element)

for element in Glu_FPM_m_8_D:
        if(len(element[1])<7000 or len(element[1])>7450):
                Glu_FPM_m_8_D.remove(element)

#print(len(CESA3),len(RPS4),len(RRS1))

dico={}

dico[filename + "_Glu_HPM_1Ax"]=Glu_HPM_1Ax
dico[filename + "_Glu_HPM_1Bx"]=Glu_HPM_1Bx
dico[filename + "_Glu_HPM_1Dx"]=Glu_HPM_1Dx
dico[filename + "_Glu_HPM_1Ay"]=Glu_HPM_1Ay
dico[filename + "_Glu_HPM_1By"]=Glu_HPM_1By
dico[filename + "_Glu_HPM_1Dy"]=Glu_HPM_1Dy
dico[filename + "_Glu_FPM_i_1_A"]=Glu_FPM_i_1_A
dico[filename + "_Glu_FPM_i_2_A"]=Glu_FPM_i_2_A
dico[filename + "_Glu_FPM_m_3_A"]=Glu_FPM_m_3_A
dico[filename + "_Glu_FPM_m_4_B"]=Glu_FPM_m_4_B
dico[filename + "_Glu_FPM_m_5_B"]=Glu_FPM_m_5_B
dico[filename + "_Glu_FPM_m_1_D"]=Glu_FPM_m_1_D
dico[filename + "_Glu_FPM_m_3_D"]=Glu_FPM_m_3_D
dico[filename + "_Glu_FPM_m_4_D"]=Glu_FPM_m_4_D
dico[filename + "_Glu_FPM_m_5_D"]=Glu_FPM_m_5_D
dico[filename + "_Glu_FPM_m_6_D"]=Glu_FPM_m_6_D
dico[filename + "_Glu_FPM_m_7_D"]=Glu_FPM_m_7_D
dico[filename + "_Glu_FPM_m_8_D"]=Glu_FPM_m_8_D


dico = {key:val for key, val in dico.items()}


for k,v in dico.items():
        print(k, len([item for item in v if item]))


for (k,v) in dico.items():
	with open("{}_test.fna".format(k), "w") as f:
		csv='\n'.join(['\n'.join(t) for t in v])
		f.write("%s\n" % (csv))  

		
