#!/bin/bash
#SBATCH --job-name=E776
#SBATCH --partition=gdec
#SBATCH --account=premium_gentyane
#SBATCH --mem=2G
#SBATCH --ntasks=1
#SBATCH --array=1-94
#SBATCH --time=3-00:00:00


n=1
for files in demux.bc*fasta; do array[n++]+=$files; done

module load python/3.4.5

echo "start demultiplexing at `date`"

for i in $(echo "${array[$SLURM_ARRAY_TASK_ID]}");
do
python Demultiplexing.py ${i} Primers-E779.txt
done

echo "end demultiplexing at `date`"